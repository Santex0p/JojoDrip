<?php
/// ETML
/// Author      : Santiago Escobar Toro
/// Date        : 2025-05-28
/// Description : Controller
namespace App\Http\Controllers;

abstract class Controller
{
    //
}


<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <!-- Styles / Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    </head>
    <body>
    <header>
        <nav>
            <div class="logo"><a href="/"><img src="<?php echo e(asset('img/Logo-jojo.png')); ?>" alt="logo"></a></div>
            <div class="menu">
                <a href="/">Accueil</a>
                <?php if(Auth::check()): ?>
                    <a href="/admin"><img src="<?php echo e(asset('img/admin.png')); ?>" alt="admin"></a>
                    <a href="/logout"><img src="<?php echo e(asset('img/logout.png')); ?>" alt="logout"></a>
                <?php else: ?>
                    <a href="/login"><img src="<?php echo e(asset('img/login.png')); ?>" alt="login"></a>
                <?php endif; ?>
                <a href="/basket"><img src="<?php echo e(asset('img/panier.png')); ?>" alt="basket"></a>
            </div>
        </nav>
    </header>
    <section class="product-edit">
    <?php if(Auth::check() && $action == 'edit'): ?>
        <form action="/update-product" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($product['id']); ?>" name="id">
            <input type="hidden" value="<?php echo e($product['photo']); ?>" name="photo-name">
            <img src="<?php echo e(asset('img/'.$product['photo'])); ?>" width="500px" alt="Product-Image">
            <label for="image">Changer d'image</label>
            <input type="file" name="image">
            <input type="text" value="<?php echo e($product['name']); ?>" name="name">
            <input type="number" value="<?php echo e($product['price']); ?>" name="price">
            <h3>Categorie</h3>
            <select name="category" id="category">
                <option value="homme" <?php echo e($product['category'] === 'homme' ? 'selected' : ''); ?>>Homme</option>
                <option value="femme" <?php echo e($product['category'] === 'femme' ? 'selected' : ''); ?>>Femme</option>
            </select>
            <h3>Description</h3>
            <textarea name="description"><?php echo e($product['description']); ?></textarea>
            <input type="hidden" value="edit" name="action">
            <button type="submit">Mettre à Jour</button>
        </form>
    </section>
    <?php else: ?>
        <section class="product-detail">
            <div class="image">
                <img src="<?php echo e(asset('img/' . $product['photo'])); ?>"
                     alt="<?php echo e($product['name']); ?>">
            </div>
            <div class="info">
                <h2><?php echo e($product['name']); ?></h2>
                <p class="price"><?php echo e($product['price']); ?> fr</p>
                <p class="description">
                    <?php echo e($product['description']); ?>

                </p>
            </div>

    <?php endif; ?>

    <form id="add-basket" action="/add-to-basket" method="GET">

        <input type="hidden" value="<?php echo e($product['id']); ?>" name="id-product">
        <button class="basket-button" type="submit" form="add-basket">Mettre au Panier</button>

    </form>
        </section>
    <footer>JojoDrip - © Santiago Escobar Toro</footer>
    </body>
</html>
<?php /**PATH C:\Users\pn63pgk\Desktop\JojoDrip\resources\views/product.blade.php ENDPATH**/ ?>
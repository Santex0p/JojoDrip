
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    </head>
    <body>
    <header>
        <nav>
            <div class="logo"><a href="/"><img src="<?php echo e(asset('img/Logo-jojo.png')); ?>" alt="logo"></a></div>
            <div class="menu">
                <a href="/">Accueil</a>
                <?php if(Auth::check()): ?>
                    <a href="/admin">Admin</a>
                    <a href="/logout">Se déconnecter</a>
                <?php else: ?>
                    <a href="/login">Se connecter</a>
                <?php endif; ?>
                <a href="/basket"><img src="<?php echo e(asset('img/panier.png')); ?>" alt="basket"></a>
            </div>
        </nav>
    </header>
        <p>Merci pour votre achat</p>
        <p>Le statut de votre achat se trouve en <?php echo e($status === 'PENDING' ? 'attente' : $status); ?>

        </p>
        <a href="/">Retourner</a>
    </body>
</html>
<?php /**PATH C:\Users\pn63pgk\Desktop\JojoDrip\resources\views/purchase-completed.blade.php ENDPATH**/ ?>
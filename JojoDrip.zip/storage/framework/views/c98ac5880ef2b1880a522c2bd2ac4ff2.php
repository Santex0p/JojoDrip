
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    </head>
    <body>
    <header>
        <nav>
            <div class="logo"><a href="/"><img src="<?php echo e(asset('img/Logo-jojo.png')); ?>" alt="logo"></a></div>
            <div class="menu">
                <a href="/">Accueil</a>
                <?php if(Auth::check()): ?>
                    <a href="/logout"><img src="<?php echo e(asset('img/logout.png')); ?>" alt="logout"></a>
                <?php else: ?>
                    <a href="/login"><img src="<?php echo e(asset('img/login.png')); ?>" alt="login"></a>
                <?php endif; ?>
                <a href="/basket"><img src="<?php echo e(asset('img/panier.png')); ?>" alt="basket"></a>
            </div>
        </nav>
    </header>
    <h2>Panneau d'administration</h2>
    <table>
        <thead>
        <tr>
            <th>Tous les produits</th>
            <th>Options</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product['name']); ?></td>
            <td>
                <form id="edit-<?php echo e($product['id']); ?>" action="/product/<?php echo e($product['id']); ?>/<?php echo e($action = 'edit'); ?>" method="GET">
                </form>
                <form id="remove-<?php echo e($product['id']); ?>" action="/remove-product" method="GET">
                    <input type="hidden" value="<?php echo e($product['id']); ?>" name="id">
                </form>
                <button type="submit" form="edit-<?php echo e($product['id']); ?>">Editer</button>
                <button type="submit" form="remove-<?php echo e($product['id']); ?>">Effacer</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        <a href="/products">Ajouter un nouveau produit</a>
    <table>
        <thead>
        <tr>
            <th>Commande - Liste</th>
            <th>Statut</th>
            <th>Changement d'état</th>
        </tr>
        </thead>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($order['id']); ?></td>
                <td><?php echo e($order['status']); ?></td>
                <td>
                    <form id="pending-<?php echo e($order['id']); ?>" action="/change-status" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($order['id']); ?>" name="id">
                        <input type="hidden" value="PENDING" name="status">
                    </form>
                    <form id="progress-<?php echo e($order['id']); ?>" action="/change-status" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($order['id']); ?>" name="id">
                        <input type="hidden" value="PROGRESS" name="status">
                    </form>
                    <form id="delivered-<?php echo e($order['id']); ?>" action="/change-status" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($order['id']); ?>" name="id">
                        <input type="hidden" value="DELIVERED" name="status">
                    </form>
                    <button type="submit" form="pending-<?php echo e($order['id']); ?>">En attente</button>
                    <button type="submit" form="progress-<?php echo e($order['id']); ?>">Progrès</button>
                    <button type="submit" form="delivered-<?php echo e($order['id']); ?>">Livré</button>
                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <footer>JojoDrip - Santiago Escobar Toro</footer>
    </body>
</html>
<?php /**PATH C:\Users\pn63pgk\Desktop\JojoDrip\resources\views/admin-panel.blade.php ENDPATH**/ ?>
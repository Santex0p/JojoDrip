
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <!-- Styles / Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>

    </head>
    <body>
    <header>
        <nav>
            <div class="logo"><a href="/"><img src="<?php echo e(asset('img/Logo-jojo.png')); ?>" alt="logo"></a></div>
            <div class="menu">
                <a href="/">Accueil</a>
                <?php if(Auth::check()): ?>
                    <a href="/admin"><img src="<?php echo e(asset('img/admin.png')); ?>" alt="admin"></a>
                    <a href="/logout"><img src="<?php echo e(asset('img/logout.png')); ?>" alt="logout"></a>
                <?php else: ?>
                    <a href="/login"><img src="<?php echo e(asset('img/login.png')); ?>" alt="login"></a>
                <?php endif; ?>
                <a href="/basket"><img src="<?php echo e(asset('img/panier.png')); ?>" alt="basket"></a>
            </div>
        </nav>
    </header>
        <section class="product-grid">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-card">
                    <img src="<?php echo e(asset('img/'.$product['photo'])); ?>" alt="<?php echo e($product['name']); ?>">
                    <div class="info">
                        <h3><?php echo e($product['name']); ?></h3>
                        <p><?php echo e(number_format($product['price'], 2)); ?> fr</p>
                        <a href="<?php echo e(url('/product/'.$product['id'].'/view')); ?>">Details</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <footer>JojoDrip - © Santiago Escobar Toro</footer>
    </body>
</html>
<?php /**PATH C:\Users\pn63pgk\Desktop\JojoDrip\resources\views/home.blade.php ENDPATH**/ ?>
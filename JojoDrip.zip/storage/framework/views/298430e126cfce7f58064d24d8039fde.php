<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    </head>
    <body>
    <header>
        <nav>
            <div class="logo"><a href="/"><img src="<?php echo e(asset('img/Logo-jojo.png')); ?>" alt="logo"></a></div>
            <div class="menu">
                <a href="/">Accueil</a>
                <?php if(Auth::check()): ?>
                    <a href="/admin"><img src="<?php echo e(asset('img/admin.png')); ?>" alt="admin"></a>
                    <a href="/logout"><img src="<?php echo e(asset('img/logout.png')); ?>" alt="logout"></a>
                <?php else: ?>
                    <a href="/login"><img src="<?php echo e(asset('img/login.png')); ?>" alt="login"></a>
                <?php endif; ?>
                <a href="/basket"><img src="<?php echo e(asset('img/panier.png')); ?>" alt="basket"></a>
            </div>
        </nav>
    </header>
    <div class="form-add">
        <form action="/add-product" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <label for="name">Nom</label>
        <input type="text" name="name">
        <label for="category">Catégorie</label>
        <select name="category" id="category">
            <option value="homme">Homme</option>
            <option value="femme">Femme</option>
        </select>
        <label for="price">Prix</label>
        <input type="number" name="price" step=".01">
        <label for="image">Image</label>
        <input type="file" name="image" >
        <label for="description">Description</label>
        <textarea name="description"></textarea>

        <button type="submit">Ajouter</button>
        </form>
    </div>
    </body>
</html>
<?php /**PATH C:\Users\pn63pgk\Desktop\JojoDrip\resources\views/add-product.blade.php ENDPATH**/ ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <!-- Styles / Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>

</head>
<body>
<header>
    <nav>
        <div class="logo"><a href="/"><img src="<?php echo e(asset('img/Logo-jojo.png')); ?>" alt="logo"></a></div>
        <div class="menu">
            <a href="/">Accueil</a>
            <?php if(Auth::check()): ?>
                <a href="/admin"><img src="<?php echo e(asset('img/admin.png')); ?>" alt="admin"></a>
                <a href="/logout"><img src="<?php echo e(asset('img/logout.png')); ?>" alt="logout"></a>
            <?php else: ?>
                <a href="/login"><img src="<?php echo e(asset('img/login.png')); ?>" alt="login"></a>
            <?php endif; ?>
            <a href="/basket"><img src="<?php echo e(asset('img/panier.png')); ?>" alt="basket"></a>
        </div>
    </nav>
</header>
        <form action="/auth" method="POST">
            <?php echo csrf_field(); ?>
        <label for="user">Utilisateur</label>
        <input id="user" name="user">

        <label for="password">Mot de passe</label>
        <input id="password" type="password" name="password">
            <button type="submit">Login</button>
        </form>
        <a href="/lost-password">Réinitialiser le mot de passe</a>
    <footer>JojoDrip - © Santiago Escobar Toro</footer>
    </body>
</html>
<?php /**PATH C:\Users\pn63pgk\Desktop\JojoDrip\resources\views/login.blade.php ENDPATH**/ ?>